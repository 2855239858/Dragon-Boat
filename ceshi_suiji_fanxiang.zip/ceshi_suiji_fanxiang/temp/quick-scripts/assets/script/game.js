(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/game.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '05a1dKadDxBm6CW4ZitKQvV', 'game', __filename);
// script/game.js

'use strict';

// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
        zuoPrefab: {
            default: null,
            type: cc.Prefab
        },
        youPrefab: {
            default: null,
            type: cc.Prefab
        },
        scoreDisplay: {
            default: null,
            type: cc.Label
        },
        Touch: {
            default: null,
            type: cc.Node
        }
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.score = 0;
        this.spanNewStar();
        this.accLeft == false;
        this.accRight == false;
    },
    spanNewStar: function spanNewStar() {
        //�����½ڵ�  �������
        var newStar;
        var randNum = Math.random() * 100 % 6;
        if (randNum < 3) {
            newStar = cc.instantiate(this.zuoPrefab);
            newStar.getComponent('zuo').game = this;
        } else {
            newStar = cc.instantiate(this.youPrefab);
            newStar.getComponent('you').game = this;
        }
        //�񳡾�������½ڵ�
        this.node.addChild(newStar);
        //�����½ڵ�λ��
        //newStar.setPosition(this.getNewStarPosition());//Ӧ��ʹ�����λ�ú���  �����ֽ���λ����Ϊ�̶�
        newStar.setPosition(cc.v2(-480, 160));
    },
    //���λ�ú���
    getNewStarPosition: function getNewStarPosition() {
        var randX = 0;
        var randY = 0;
        randX = this.node.width / 5;
        randY = this.node.height / 5;
        return cc.v2(randX, randY);
    },
    gainScore: function gainScore() {
        this.score += 1;
        this.scoreDisplay.string = 'Score: ' + this.score.toString();
    },
    addTouchEvent: function addTouchEvent() {
        var self = this;
        this.node.on(cc.Node.EventType.TOUCH_START, function (event) {
            //
            var np = event.getLocation();

            if (np.x * np.x + np.y * np.y < 28900 || (np.x - 960) * (np.x - 960) + np.y * np.y < 28900) {
                self.accLeft = true;self.accRight = false;
            } else if (np.x * np.x + np.y * np.y > 28900 && np.x * np.x + np.y * np.y < 62500 || (np.x - 960) * (np.x - 960) + np.y * np.y > 28900 && (np.x - 960) * (np.x - 960) + np.y * np.y < 62500) {
                self.accLeft = false;self.accRight = true;
            }
        });
        this.node.on(cc.Node.EventType.TOUCH_ENDED, function (event) {
            self.accLeft = false;self.accRight = false;
        });
    },

    start: function start() {
        this.spanNewStar();
    }
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=game.js.map
        